Copyright © 2024 CR@CKER B0Y 1.0. All rights reserved.

This Windows Batch script, CR@CKER B0Y 1.0, is designed to simulate intrusive behavior on a computer by altering system settings to create 
a sense of system takeover. Use only in a test environment or virtual machine to understand the potential impacts of such modifications 
on a Windows system. This script is strictly for educational purposes and not intended for malicious use.
------------------------------------------------------------------------------------------------------------------------------------
Desktop Appearance Modification: The script begins by changing the desktop background color to black, altering the user interface 
to create a sense of control takeover. Shutdown of Windows Interface (explorer.exe): By forcibly terminating explorer.exe, the script 
makes the desktop and navigation bars inaccessible, giving the impression of a frozen system. Warning Messages via VBScript: 
Multiple VBScript files are created in the user’s startup folder. Each time the system starts, these scripts display intimidating 
pop-up messages, such as "No Escape" and "Run Away," simulating a threatening presence. Creation of Fictitious User Accounts: 
To simulate unauthorized access, the script creates user accounts with intimidating names like CRACKERBOY and DONOTTRYTOLOGIN.
Scheduled Restart with Infection Message: The script schedules a system restart, notifying the user with a message claiming the system 
is "infected."
-----------------------------------------------------------------------------------------------------------------------------------
Any damage caused to the computer as a result of running this script is not the responsibility of the author.

Copyright © 2024 CR@CKER B0Y 1.0. All rights reserved.
